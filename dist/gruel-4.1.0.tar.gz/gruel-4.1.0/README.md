# gruel

Another scraping framework

## Installation

Install with:

```console
pip install gruel
```
