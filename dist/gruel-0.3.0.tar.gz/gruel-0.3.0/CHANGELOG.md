# Changelog

## v0.2.0 (2023-10-25)

#### Fixes

* fix Gruel.name not returning the given name if there was one
#### Performance improvements

* improve logging
#### Refactorings

* make logprint a member function
* replace printbuddies.PoolBar with quickpool.ThreadPool


## v0.1.0 (2023-10-23)

#### Performance improvements

* add additional logging

## v0.0.2 (2023-10-19)

#### Fixes

* fix progbar display when using default option in scrape()


## v0.0.1 (2023-10-19)

#### Fixes

* fix partially initialized import error



