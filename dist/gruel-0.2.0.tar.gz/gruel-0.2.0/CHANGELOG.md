# Changelog

## v0.1.0 (2023-10-23)

#### Performance improvements

* add additional logging

## v0.0.2 (2023-10-19)

#### Fixes

* fix progbar display when using default option in scrape()


## v0.0.1 (2023-10-19)

#### Fixes

* fix partially initialized import error



