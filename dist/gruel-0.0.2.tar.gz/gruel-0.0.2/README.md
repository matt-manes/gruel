# gruel

Another scraping framework

## Installation

Install with:

<pre>
pip install gruel
</pre>

